package com.empire.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.atomic.AtomicBoolean

class GameAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var instance: GameAccessibilityService? = null
            private set
    }

    private val handler = Handler(Looper.getMainLooper())
    private val busy = AtomicBoolean(false)
    @Volatile private var destroyed = false
    private val prefs by lazy { getSharedPreferences(AppPrefs.FILE, MODE_PRIVATE) }
    private lateinit var recognizer: TextRecognizer
    private var recognizerCreated = false
    private var closeWhenIdle = false
    private var lastTap = 0L
    private var tapCount = 0
    private val scanDelay = 2500L
    private val tapDelay = 8000L
    private val maxTaps = 20

    private val scanRunnable = object : Runnable {
        override fun run() {
            if (destroyed) return
            if (prefs.getBoolean(AppPrefs.ENABLED, false)) scanScreen()
            if (!destroyed) handler.postDelayed(this, scanDelay)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        destroyed = false
        instance = this
        if (!recognizerCreated) {
            recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            recognizerCreated = true
        }
        handler.removeCallbacks(scanRunnable)
        handler.post(scanRunnable)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    private fun scanScreen() {
        if (destroyed || !prefs.getBoolean(AppPrefs.ENABLED, false) ||
            !busy.compareAndSet(false, true)) return
        clearDetection("Поиск кнопки…")

        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor,
                object : TakeScreenshotCallback {
                    override fun onSuccess(result: ScreenshotResult) {
                        var bitmap: Bitmap? = null
                        try {
                            val buffer = result.hardwareBuffer
                            val hardware = try {
                                Bitmap.wrapHardwareBuffer(buffer, result.colorSpace)
                            } finally {
                                buffer.close()
                            }
                            bitmap = hardware?.copy(Bitmap.Config.ARGB_8888, false)
                            hardware?.recycle()
                        } catch (e: Exception) {
                            reportError(e)
                            finishScan()
                            return
                        }

                        val image = bitmap
                        if (image == null) {
                            reportError(IllegalStateException("Не удалось подготовить снимок"))
                            finishScan()
                            return
                        }
                        if (destroyed || !prefs.getBoolean(AppPrefs.ENABLED, false)) {
                            image.recycle()
                            finishScan()
                            return
                        }

                        try {
                            recognizer.process(InputImage.fromBitmap(image, 0))
                                .addOnSuccessListener { resultText ->
                                    if (destroyed ||
                                        !prefs.getBoolean(AppPrefs.ENABLED, false)) {
                                        return@addOnSuccessListener
                                    }
                                    val line = resultText.textBlocks.flatMap { it.lines }
                                        .firstOrNull {
                                            it.boundingBox != null && GameRules.matches(it.text)
                                        }
                                    val rect = line?.boundingBox
                                    if (line == null || rect == null) {
                                        clearDetection("Кнопка не найдена")
                                    } else {
                                        prefs.edit()
                                            .putString(AppPrefs.DETECTED, line.text)
                                            .putFloat(AppPrefs.X, (rect.left + rect.right) / 2f)
                                            .putFloat(AppPrefs.Y, (rect.top + rect.bottom) / 2f)
                                            .putLong(AppPrefs.DETECTED_AT, System.currentTimeMillis())
                                            .apply()
                                    }
                                }
                                .addOnFailureListener { reportError(it) }
                                .addOnCompleteListener {
                                    image.recycle()
                                    finishScan()
                                }
                        } catch (e: Exception) {
                            image.recycle()
                            reportError(e)
                            finishScan()
                        }
                    }

                    override fun onFailure(errorCode: Int) {
                        reportError(IllegalStateException("Ошибка снимка: $errorCode"))
                        finishScan()
                    }
                })
        } catch (e: Exception) {
            reportError(e)
            finishScan()
        }
    }

    private fun clearDetection(message: String) {
        prefs.edit().putString(AppPrefs.DETECTED, message)
            .putFloat(AppPrefs.X, -1f).putFloat(AppPrefs.Y, -1f)
            .putLong(AppPrefs.DETECTED_AT, 0L).apply()
    }

    private fun reportError(error: Exception) {
        if (!destroyed) clearDetection("Ошибка: ${error.localizedMessage ?: error.javaClass.simpleName}")
    }

    private fun finishScan() {
        busy.set(false)
        if (closeWhenIdle && recognizerCreated) {
            closeWhenIdle = false
            recognizer.close()
            recognizerCreated = false
        }
    }

    fun tapAt(x: Float, y: Float): Boolean {
        if (destroyed || !prefs.getBoolean(AppPrefs.ENABLED, false) ||
            !x.isFinite() || !y.isFinite()) return false
        val now = System.currentTimeMillis()
        val detectedAt = prefs.getLong(AppPrefs.DETECTED_AT, 0L)
        if (detectedAt <= 0L || now < detectedAt || now - detectedAt > 10000L) return false
        if (now - lastTap < tapDelay || tapCount >= maxTaps) return false
        val metrics = resources.displayMetrics
        if (x < 0 || y < 0 || x >= metrics.widthPixels || y >= metrics.heightPixels) return false
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, 100L)).build()
        val accepted = dispatchGesture(gesture, null, null)
        if (accepted) {
            lastTap = now
            tapCount++
        }
        return accepted
    }

    override fun onInterrupt() {
        handler.removeCallbacks(scanRunnable)
        clearDetection("Служба прервана")
        if (!destroyed && prefs.getBoolean(AppPrefs.ENABLED, false)) {
            handler.postDelayed(scanRunnable, scanDelay)
        }
    }

    override fun onDestroy() {
        destroyed = true
        handler.removeCallbacksAndMessages(null)
        if (instance === this) instance = null
        prefs.edit().putBoolean(AppPrefs.ENABLED, false).apply()
        if (recognizerCreated) {
            if (busy.get()) closeWhenIdle = true
            else {
                recognizer.close()
                recognizerCreated = false
            }
        }
        super.onDestroy()
    }
}