package com.empire.assistant

object AppPrefs {
    const val FILE = "empire_assistant"
    const val ENABLED = "enabled"
    const val DETECTED = "detected_text"
    const val X = "detected_x"
    const val Y = "detected_y"
    const val DETECTED_AT = "detected_at"
}