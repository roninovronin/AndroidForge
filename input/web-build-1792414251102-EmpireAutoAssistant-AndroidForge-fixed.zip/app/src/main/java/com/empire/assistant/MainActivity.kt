package com.empire.assistant

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences(AppPrefs.FILE, MODE_PRIVATE) }
    private lateinit var status: TextView
    private lateinit var toggle: Switch

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(32, 32, 32, 24)
        }
        layout.addView(TextView(this).apply {
            text = "Empire Auto Assistant"
            textSize = 25f
        })
        layout.addView(Button(this).apply {
            text = "Настройки специальных возможностей"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        })
        toggle = Switch(this).apply {
            text = "Разрешить распознавание"
            isChecked = prefs.getBoolean(AppPrefs.ENABLED, false)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean(AppPrefs.ENABLED, checked).apply()
                if (!checked) clearDetection()
                refreshStatus()
            }
        }
        layout.addView(toggle)
        status = TextView(this).apply {
            textSize = 16f
            setPadding(0, 20, 0, 20)
        }
        layout.addView(status)
        layout.addView(Button(this).apply {
            text = "Обновить результат"
            setOnClickListener { refreshStatus() }
        })
        layout.addView(Button(this).apply {
            text = "Подтвердить одно нажатие"
            setOnClickListener {
                val x = prefs.getFloat(AppPrefs.X, -1f)
                val y = prefs.getFloat(AppPrefs.Y, -1f)
                val time = prefs.getLong(AppPrefs.DETECTED_AT, 0L)
                if (!prefs.getBoolean(AppPrefs.ENABLED, false)) {
                    status.text = "Сначала включи распознавание"
                } else if (x < 0 || y < 0 || time <= 0 ||
                    System.currentTimeMillis() - time > 10000) {
                    status.text = "Нет свежего результата"
                } else {
                    val service = GameAccessibilityService.instance
                    status.text = when {
                        service == null -> "Включи службу доступности"
                        service.tapAt(x, y) -> "Жест отправлен. Проверь экран игры."
                        else -> "Нажатие отклонено"
                    }
                }
            }
        })
        layout.addView(Button(this).apply {
            text = "СТОП"
            setOnClickListener {
                prefs.edit().putBoolean(AppPrefs.ENABLED, false).apply()
                toggle.isChecked = false
                clearDetection()
                status.text = "Остановлено"
            }
        })
        setContentView(ScrollView(this).apply { addView(layout) })
        refreshStatus()
    }

    private fun clearDetection() {
        prefs.edit().putString(AppPrefs.DETECTED, "пока ничего")
            .putFloat(AppPrefs.X, -1f).putFloat(AppPrefs.Y, -1f)
            .putLong(AppPrefs.DETECTED_AT, 0L).apply()
    }

    private fun refreshStatus() {
        val enabled = prefs.getBoolean(AppPrefs.ENABLED, false)
        val detected = prefs.getString(AppPrefs.DETECTED, "пока ничего")
        status.text = when {
            !enabled -> "Распознавание выключено\nНайдено: $detected"
            GameAccessibilityService.instance == null ->
                "Служба доступности не подключена\nНайдено: $detected"
            else -> "Распознавание разрешено\nНайдено: $detected"
        }
    }

    override fun onResume() {
        super.onResume()
        if (::toggle.isInitialized) {
            toggle.isChecked = prefs.getBoolean(AppPrefs.ENABLED, false)
            refreshStatus()
        }
    }
}