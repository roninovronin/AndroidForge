package com.empire.assistant

import java.util.Locale

data class GameRule(val keywords: List<String>, val enabled: Boolean = true)

object GameRules {
    val rules = listOf(
        GameRule(listOf("collect", "claim")),
        GameRule(listOf("daily reward", "free reward")),
        GameRule(listOf("upgrade", "improve")),
        GameRule(listOf("Р·Р°Р±СЂР°С‚СЊ", "РїРѕР»СѓС‡РёС‚СЊ")),
        GameRule(listOf("РЅР°РіСЂР°РґР°", "СѓР»СѓС‡С€РёС‚СЊ")),
        GameRule(listOf("РєСѓРїРёС‚СЊ", "РЅР°РЅСЏС‚СЊ"))
    )

    fun matches(line: String): Boolean {
        val normalized = line.trim().lowercase(Locale.ROOT)
        return rules.any { rule ->
            rule.enabled && rule.keywords.any {
                normalized.contains(it.lowercase(Locale.ROOT))
            }
        }
    }
}