package com.empire.assistant

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences(AppPrefs.FILE, MODE_PRIVATE) }
    private lateinit var status: TextView
    private lateinit var toggle: Switch

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(32, 32, 32, 24)
        }
        layout.addView(TextView(this).apply {
            text = "Empire Auto Assistant"
            textSize = 25f
        })
        layout.addView(Button(this).apply {
            text = "РќР°СЃС‚СЂРѕР№РєРё СЃРїРµС†РёР°Р»СЊРЅС‹С… РІРѕР·РјРѕР¶РЅРѕСЃС‚РµР№"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        })
        toggle = Switch(this).apply {
            text = "Р Р°Р·СЂРµС€РёС‚СЊ СЂР°СЃРїРѕР·РЅР°РІР°РЅРёРµ"
            isChecked = prefs.getBoolean(AppPrefs.ENABLED, false)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean(AppPrefs.ENABLED, checked).apply()
                if (!checked) clearDetection()
                refreshStatus()
            }
        }
        layout.addView(toggle)
        status = TextView(this).apply {
            textSize = 16f
            setPadding(0, 20, 0, 20)
        }
        layout.addView(status)
        layout.addView(Button(this).apply {
            text = "РћР±РЅРѕРІРёС‚СЊ СЂРµР·СѓР»СЊС‚Р°С‚"
            setOnClickListener { refreshStatus() }
        })
        layout.addView(Button(this).apply {
            text = "РџРѕРґС‚РІРµСЂРґРёС‚СЊ РѕРґРЅРѕ РЅР°Р¶Р°С‚РёРµ"
            setOnClickListener {
                val x = prefs.getFloat(AppPrefs.X, -1f)
                val y = prefs.getFloat(AppPrefs.Y, -1f)
                val time = prefs.getLong(AppPrefs.DETECTED_AT, 0L)
                if (!prefs.getBoolean(AppPrefs.ENABLED, false)) {
                    status.text = "РЎРЅР°С‡Р°Р»Р° РІРєР»СЋС‡Рё СЂР°СЃРїРѕР·РЅР°РІР°РЅРёРµ"
                } else if (x < 0 || y < 0 || time <= 0 ||
                    System.currentTimeMillis() - time > 10000) {
                    status.text = "РќРµС‚ СЃРІРµР¶РµРіРѕ СЂРµР·СѓР»СЊС‚Р°С‚Р°"
                } else {
                    val service = GameAccessibilityService.instance
                    status.text = when {
                        service == null -> "Р’РєР»СЋС‡Рё СЃР»СѓР¶Р±Сѓ РґРѕСЃС‚СѓРїРЅРѕСЃС‚Рё"
                        service.tapAt(x, y) -> "Р–РµСЃС‚ РѕС‚РїСЂР°РІР»РµРЅ. РџСЂРѕРІРµСЂСЊ СЌРєСЂР°РЅ РёРіСЂС‹."
                        else -> "РќР°Р¶Р°С‚РёРµ РѕС‚РєР»РѕРЅРµРЅРѕ"
                    }
                }
            }
        })
        layout.addView(Button(this).apply {
            text = "РЎРўРћРџ"
            setOnClickListener {
                prefs.edit().putBoolean(AppPrefs.ENABLED, false).apply()
                toggle.isChecked = false
                clearDetection()
                status.text = "РћСЃС‚Р°РЅРѕРІР»РµРЅРѕ"
            }
        })
        setContentView(ScrollView(this).apply { addView(layout) })
        refreshStatus()
    }

    private fun clearDetection() {
        prefs.edit().putString(AppPrefs.DETECTED, "РїРѕРєР° РЅРёС‡РµРіРѕ")
            .putFloat(AppPrefs.X, -1f).putFloat(AppPrefs.Y, -1f)
            .putLong(AppPrefs.DETECTED_AT, 0L).apply()
    }

    private fun refreshStatus() {
        val enabled = prefs.getBoolean(AppPrefs.ENABLED, false)
        val detected = prefs.getString(AppPrefs.DETECTED, "РїРѕРєР° РЅРёС‡РµРіРѕ")
        status.text = when {
            !enabled -> "Р Р°СЃРїРѕР·РЅР°РІР°РЅРёРµ РІС‹РєР»СЋС‡РµРЅРѕ\nРќР°Р№РґРµРЅРѕ: $detected"
            GameAccessibilityService.instance == null ->
                "РЎР»СѓР¶Р±Р° РґРѕСЃС‚СѓРїРЅРѕСЃС‚Рё РЅРµ РїРѕРґРєР»СЋС‡РµРЅР°\nРќР°Р№РґРµРЅРѕ: $detected"
            else -> "Р Р°СЃРїРѕР·РЅР°РІР°РЅРёРµ СЂР°Р·СЂРµС€РµРЅРѕ\nРќР°Р№РґРµРЅРѕ: $detected"
        }
    }

    override fun onResume() {
        super.onResume()
        if (::toggle.isInitialized) {
            toggle.isChecked = prefs.getBoolean(AppPrefs.ENABLED, false)
            refreshStatus()
        }
    }
}